﻿namespace $safeprojectname$

open Pit
open Pit.Dom

module App =
    [<DomEntryPoint>]
    [<Js>]
    let main() =        
        alert("Hello World!!!")